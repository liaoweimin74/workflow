# ui-visual-theme Specification

## Purpose
TBD - created by archiving change sitewide-beautify. Update Purpose after archive.
## Requirements
### Requirement: 设计令牌体系

系统 SHALL 提供一套集中定义的全站视觉设计令牌（Design Tokens），包括靛蓝主色、青色点缀色、
浅蓝紫背景色、卡片底色/边框/阴影、圆角与字体层级；令牌值 MUST 与参考稿程序化提取的配色一致
（主色 #5755ee / #5452d3、青点缀 #46c9d6 / #48e0dd、背景 #f1f4fe 系、侧边栏 #e6e9fb 系），
并以 `DESIGN.md` 作为令牌的权威来源；实现中出现的非令牌十六进制颜色值 MUST 被补入 `DESIGN.md`。

#### Scenario: 令牌集中定义
- **WHEN** 开发者在 `style.css` 中读取主题变量（如 `--el-color-primary`）
- **THEN** 变量值等于令牌定义的靛蓝主色，且 `DESIGN.md` 记录了相同值

#### Scenario: 非令牌色值合规
- **WHEN** 对前端源码执行十六进制颜色扫描
- **THEN** 每个非令牌 hex 色值均在 `DESIGN.md` 中有对应令牌记录

---

### Requirement: Element Plus 全站主题覆盖

系统 SHALL 通过覆写 Element Plus CSS 变量（`--el-color-*`、`--el-border-radius-*`、`--el-bg-color`、
`--el-border-color-*`、`--el-text-color-*`、`--el-fill-color-*`）使全站 Element Plus 组件
（按钮、表格、表单、菜单、对话框、标签、卡片）自动呈现新主题，而无需逐组件修改样式；
覆写 MUST 同时提供亮色（`:root`）与暗色（`.dark`）两套取值。

#### Scenario: 全站自动换肤
- **WHEN** 用户打开任一使用 Element Plus 组件的页面（如流程中心、用户列表）
- **THEN** 该页面的主色按钮、表格边框、表单控件呈现靛蓝主色主题，且未对组件做局部样式修改

#### Scenario: 暗色变量存在
- **WHEN** 系统处于暗色模式
- **THEN** Element Plus 组件使用暗色变量取值（深蓝紫底、微亮靛蓝主色 #7c7ff0、青点缀 #5ee7e8）

---

### Requirement: 布局外壳风格

系统 SHALL 将后台布局外壳（AdminLayout 的侧边栏、顶栏、页签栏、右键菜单及 SubMenu 菜单项）
呈现为参考稿风格的蓝紫科技感外观：侧边栏底色 MUST 为浅蓝紫（亮色 #eef0fc / 暗色深蓝紫 #161b36），
当前激活菜单项 MUST 以靛蓝文字加蓝紫圆角底块高亮（参考选中态 #e9eaff 系），
激活页签 MUST 显示青色（#46c9d6）顶部指示条，logo 区 MUST 使用靛蓝渐变底。

#### Scenario: 侧边栏与菜单高亮
- **WHEN** 用户进入后台首页且侧边栏可见
- **THEN** 侧边栏为蓝紫色调，当前所在菜单项为靛蓝文字加浅蓝紫圆角底块

#### Scenario: 页签激活指示
- **WHEN** 用户在页签栏切换到某一页签
- **THEN** 激活页签顶部显示青色指示条，未激活页签为灰字且 hover 呈浅蓝紫底

---

### Requirement: 页面背景氛围

系统 SHALL 将全局页面背景由纯灰白升级为浅蓝紫渐变氛围底色（如
`linear-gradient(#f4f6fe, #eef1fc)`），表单页、列表页等业务页面的内容卡片 MUST 使用
白底加淡蓝紫边框与柔和阴影（如 `box-shadow: 0 1px 3px rgba(87,85,238,0.06)`）。

#### Scenario: 渐变背景生效
- **WHEN** 用户浏览任一业务页面
- **THEN** 页面背景呈现浅蓝紫渐变而非纯灰白，内容卡片为白底淡蓝紫边框

---

### Requirement: 登录页品牌化

系统 SHALL 将登录页升级为品牌化风格：背景 MUST 使用蓝紫对角渐变叠加青色光晕装饰
（纯 CSS 渐变实现，不依赖图片），登录卡片 MUST 使用大圆角（20px）与蓝紫边框，
主登录按钮 MUST 为靛蓝渐变底，页面 MUST 保留"安全第一 · 规范作业"文案。

#### Scenario: 登录页观感
- **WHEN** 用户打开登录页
- **THEN** 页面呈现蓝紫渐变背景与青色光晕，居中登录卡片为大圆角白底蓝紫边，登录按钮为靛蓝渐变

---

### Requirement: 仪表盘首屏呈现

系统 SHALL 将仪表盘首页呈现为参考稿风格的高信息密度布局：顶部 MUST 为浅蓝紫渐变欢迎横幅
（左侧靛蓝标题文字、右侧青色装饰元素，纯 CSS/SVG 实现），统计卡片区 MUST 展示至少 4 张
主题色统计卡片（白底、圆角、左上角靛蓝/青色图标圆标、大号数值字、维度描述），
内容区 MUST 提供纯 CSS/SVG 装饰性图表（柱状趋势与环形占比示意）以丰富视觉节奏；
装饰图表 MUST 不标注具体数值、不引入第三方图表库、不伪造业务数据。

#### Scenario: 仪表盘布局
- **WHEN** 用户登录后进入首页
- **THEN** 页面依次呈现渐变欢迎横幅、主题色统计卡片区与装饰性图表区，全部元素无需后端数据即完整渲染

#### Scenario: 无新依赖
- **WHEN** 检查前端依赖清单
- **THEN** 未因仪表盘新增 echarts、chart.js 等图表库依赖

---

### Requirement: 暗色模式一致体验

系统 SHALL 使暗色模式与亮色主题保持语义一致的蓝紫科技风格：页面底色 MUST 为深蓝紫
（#12162b）、卡片底色 MUST 为 #1b2040、边框 MUST 为 #2a3054，主色与点缀色 MUST 在暗色下
保持足够对比度（主色微亮 #7c7ff0、青色 #5ee7e8），文字层级 MUST 使用 #e5e7eb / #94a3b8。

#### Scenario: 暗色切换
- **WHEN** 用户在顶栏切换至暗色模式并浏览首页、列表页与流程中心
- **THEN** 页面背景为深蓝紫、卡片为深蓝紫浅一档色，按钮/菜单/高亮态使用微亮靛蓝与青色，文字可读

---

### Requirement: 流程中心精修

系统 SHALL 使流程中心的搜索卡片与流程卡片列表呈现统一的新主题：流程卡片 hover 时 MUST
加深阴影并显示青色调强调，卡片标题/描述/版本标签布局 MUST 保持现有结构不变。

#### Scenario: 流程卡片交互
- **WHEN** 用户在流程中心将鼠标悬停于某流程卡片
- **THEN** 卡片阴影加深并呈现青色强调效果，标题、描述与版本标签保持原位

---

### Requirement: 业务逻辑零改动

系统 MUST 保证本次视觉美化不更改任何业务逻辑、接口调用、路由结构、状态管理或
组件 keep-alive 缓存机制；bpmn-js 流程设计器与 form-create 表单设计器的画布内部
MUST 保持原有样式不变（仅外壳与 Element Plus 表层生效）。

#### Scenario: 逻辑回归
- **WHEN** 对美化后的系统执行登录、菜单导航、页签切换、流程发起等关键交互
- **THEN** 所有交互行为与美化前一致，无路由跳转、数据加载或状态变更异常

#### Scenario: 设计器画布不变
- **WHEN** 用户打开 bpmn-js 流程设计器或 form-create 表单设计器
- **THEN** 画布内部的节点、连线、控件样式与美化前一致

