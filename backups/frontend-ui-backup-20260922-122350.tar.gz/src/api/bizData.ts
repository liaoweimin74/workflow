import http from '@/utils/http'
import type { R } from '@/types/common'

/** 业务数据列映射项（与后端 ColumnConfig 对齐） */
export interface ColumnConfigItem {
  key: string
  label: string
  columnType: string
  length: number | null
  scale: number | null
  required: boolean
  unique: boolean
  indexed: boolean
  /** 隐藏列（如 data-picker 引用列的 <key>_text 冗余列） */
  hidden?: boolean
  /** data-picker 引用配置（JSON 字符串，可空） */
  pickerConfig?: string | null
  /** 组件类型（form-create rule type，如 colorPicker/elTransfer；供列表定制渲染） */
  componentType?: string | null
  /** 是否可排序（数据源 metadata 声明；缺省 undefined=未推导，前端按列类型兜底） */
  sortable?: boolean
  /** 是否可筛选（数据源 metadata 声明；缺省 undefined=未推导） */
  filterable?: boolean
  /** 查询方式（eq/like/range；缺省 undefined=未配置，由前端按列类型推导） */
  matchType?: string
  /** 不支持展示的列（如子表占位字段，后端无实际列） */
  unsupported?: boolean
  /** 子表列定义（group/tableForm/subForm 内部子字段） */
  subColumns?: ColumnConfigItem[]
}

/** 业务数据行 */
export interface BizDataVO {
  id: string
  data: Record<string, unknown>
  version: number
  createdAt: string
  updatedAt: string
}

/** 后端 BizDataPageVO 分页响应 */
export interface BizDataPageResult {
  records: BizDataVO[]
  total: number
  page: number
  size: number
}

export interface BizDataQueryParams {
  page?: number
  size?: number
  keyword?: string
  keywordColumn?: string
  sort?: string
  order?: string
  filter?: Record<string, unknown>
  /** 运行时查询参数（sql 模式按 params 白名单绑定到 :paramName 占位符）；对象序列化为 JSON 字符串 */
  params?: Record<string, unknown>
}

export const bizDataApi = {
  list(formKey: string, params: BizDataQueryParams): Promise<R<BizDataPageResult>> {
    const query: Record<string, unknown> = { ...params }
    // filter 对象序列化为 JSON 字符串（后端 BizDataQueryRequest.filter 为 String）
    if (query.filter && typeof query.filter === 'object') {
      query.filter = JSON.stringify(query.filter)
    }
    // params 对象序列化为 JSON 字符串（后端 BizDataQueryRequest.params 为 String）
    if (query.params && typeof query.params === 'object') {
      query.params = JSON.stringify(query.params)
    }
    return http.get(`/v1/biz-data/${formKey}`, { params: query })
  },

  detail(formKey: string, id: string): Promise<R<BizDataVO>> {
    return http.get(`/v1/biz-data/${formKey}/${id}`)
  },

  create(formKey: string, data: Record<string, unknown>): Promise<R<BizDataVO>> {
    return http.post(`/v1/biz-data/${formKey}`, data)
  },

  update(formKey: string, id: string, data: Record<string, unknown>, version: number): Promise<R<BizDataVO>> {
    return http.put(`/v1/biz-data/${formKey}/${id}`, { ...data, version })
  },

  remove(formKey: string, id: string): Promise<R<void>> {
    return http.delete(`/v1/biz-data/${formKey}/${id}`)
  },

  /** 批量解析数据显示文本（data-picker 引用还原） */
  resolve(formKey: string, ids: string[], displayField?: string): Promise<R<Record<string, string>>> {
    return http.get(`/v1/biz-data/${formKey}/resolve`, {
      params: { ids: ids.join(','), displayField },
    })
  },

  /** 引用感知：各业务表单被 dataPicker 引用统计（{ formKey: { count, referencedBy } }，仅含被引用者） */
  referencedCount(): Promise<R<Record<string, { count: number; referencedBy: string[] }>>> {
    return http.get('/v1/biz-data/referenced-count')
  },
}
