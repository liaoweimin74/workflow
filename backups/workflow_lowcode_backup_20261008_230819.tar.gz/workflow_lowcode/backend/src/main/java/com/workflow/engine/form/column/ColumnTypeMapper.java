package com.workflow.engine.form.column;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 组件类型 → 列类型映射器。
 * 将 form-create 组件类型映射为物理表列类型，并提供白名单校验。
 */
public final class ColumnTypeMapper {

    /** 允许的列类型白名单 */
    private static final Set<String> ALLOWED_TYPES = Set.of(
            "VARCHAR", "TEXT", "INT", "DECIMAL", "DATE", "DATETIME", "TINYINT", "JSON", "LONGTEXT");

    /** 不支持映射为可查询列的组件（人员/部门选择、分割线、容器等） */
    private static final Set<String> UNSUPPORTED_COMPONENTS = Set.of(
            "userPicker", "deptPicker", "divider", "groupContainer");

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private ColumnTypeMapper() {}

    /**
     * 将组件类型映射为列映射草案。
     *
     * @param componentType form-create rule 的 type 字段
     * @param props         form-create rule 的 props（用于子类型判定：日期类型/数字精度）
     * @return 列映射草案；不支持映射的组件返回 null
     */
    public static ColumnConfig mapComponentToColumn(String componentType, Map<String, Object> props) {
        if (componentType == null || UNSUPPORTED_COMPONENTS.contains(componentType)) {
            return null;
        }

        ColumnConfig c = new ColumnConfig();
        c.setComponentType(componentType);
        switch (componentType) {
            case "input" -> applyString(c, 255);
            case "textarea", "RichText", "richText" -> applyText(c);
            case "inputNumber" -> applyNumber(c, props);
            case "select" -> applyJson(c);
            case "radio" -> applyString(c, 255);
            case "cascader" -> applyJson(c);
            case "checkbox", "multiSelect", "multiSelectPro" -> applyJson(c);
            case "LookupPicker" -> {
                // 查找带回：存显示文本（VARCHAR 255）
                applyString(c, 255);
            }
            case "DatePicker", "datePicker" -> applyDate(c, props);
            case "TimePicker", "timePicker" -> applyString(c, 32);
            case "switch" -> applyTinyint(c);
            case "Upload", "upload", "fileUpload" -> applyJson(c);
            case "rate" -> applyInt(c);
            case "colorPicker" -> applyString(c, 16);
            case "tree" -> applyTree(c, props);
            case "elTreeSelect" -> applyJson(c);
            case "elTransfer" -> applyJson(c);
            case "fcEditor" -> applyText(c);
            case "signaturePad" -> applyText(c);
            case "subForm" -> applyJson(c);
            case "slider" -> applySlider(c, props);
            default -> {
                return null;
            }
        }
        return c;
    }

    private static void applyString(ColumnConfig c, Integer length) {
        c.setColumnType("VARCHAR");
        c.setLength(length);
    }

    private static void applyText(ColumnConfig c) {
        c.setColumnType("TEXT");
    }

    private static void applyNumber(ColumnConfig c, Map<String, Object> props) {
        int precision = 0;
        if (props != null && props.get("precision") instanceof Number n) {
            precision = n.intValue();
        }
        if (precision > 0) {
            c.setColumnType("DECIMAL");
            c.setLength(18);
            c.setScale(precision);
        } else {
            c.setColumnType("INT");
        }
    }

    private static void applyDate(ColumnConfig c, Map<String, Object> props) {
        String subType = props == null ? null : String.valueOf(props.get("type"));
        if ("datetime".equals(subType) || "datetimerange".equals(subType)) {
            c.setColumnType("DATETIME");
        } else {
            c.setColumnType("DATE");
        }
    }

    private static void applyTinyint(ColumnConfig c) {
        c.setColumnType("TINYINT");
        c.setLength(1);
    }

    private static void applyInt(ColumnConfig c) {
        c.setColumnType("INT");
    }

    private static void applyTree(ColumnConfig c, Map<String, Object> props) {
        boolean multi = props != null && (Boolean.TRUE.equals(props.get("multiple"))
                || Boolean.TRUE.equals(props.get("showCheckbox")));
        if (multi) {
            applyJson(c);
        } else {
            applyString(c, 255);
        }
    }

    private static void applyJson(ColumnConfig c) {
        c.setColumnType("JSON");
    }

    /**
     * 滑块映射：
     * - range=true（双滑块，值为 [min,max] 数组）→ JSON
     * - step 为小数（单选，值可能为小数）→ DECIMAL(18, 小数位)
     * - 其余（单选整数）→ INT
     */
    private static void applySlider(ColumnConfig c, Map<String, Object> props) {
        if (props != null && Boolean.TRUE.equals(props.get("range"))) {
            applyJson(c);
            return;
        }
        if (props != null && props.get("step") instanceof Number n) {
            String plain = new java.math.BigDecimal(n.toString()).stripTrailingZeros().toPlainString();
            int dot = plain.indexOf('.');
            if (dot >= 0) {
                c.setColumnType("DECIMAL");
                c.setLength(18);
                c.setScale(plain.length() - dot - 1);
                return;
            }
        }
        applyInt(c);
    }

    /**
     * 数组值组件判定：值以数组/JSON 存储（单选为长度 1 的数组）。
     * select 单选/多选、tree 单选/多选等统一按数组组件处理（查询走 <key>_text 文本列，
     * 主列仅存值用于回显），与前端 ColumnConfigDialog 数组组件集合保持一致。
     */
    private static boolean isArrayComponent(String componentType) {
        return switch (componentType) {
            case "select", "checkbox", "multiSelect", "multiSelectPro", "elTransfer", "tree", "elTreeSelect", "cascader" -> true;
            default -> false;
        };
    }

    /**
     * 数组值组件双列映射（value + 显示文本冗余列）：
     * <key> JSON 存叶子 value 数组（单选 ["x"]、多选 ["x","y"]）
     * <key>_text VARCHAR(255) 存显示文本（hidden=true，仅参与 CRUD 写入，供列表显示与模糊查询）
     *
     * 非数组组件退回单列映射，不生成 <key>_text。
     *
     * @param key           字段 key
     * @param componentType form-create rule 的 type
     * @param props         form-create rule 的 props（单列映射时用于列类型判定）
     * @return 双列（主列 + text 列）或单列映射；组件不支持时返回空列表
     */
    public static List<ColumnConfig> mapArrayComponentToColumns(String key, String componentType,
                                                                Map<String, Object> props) {
        if (!isArrayComponent(componentType)) {
            ColumnConfig single = mapComponentToColumn(componentType, props);
            if (single == null) {
                return List.of();
            }
            single.setKey(key);
            return List.of(single);
        }
        ColumnConfig main = new ColumnConfig();
        main.setKey(key);
        main.setColumnType("JSON");
        main.setComponentType(componentType);

        ColumnConfig text = new ColumnConfig();
        text.setKey(key + "_text");
        text.setColumnType("VARCHAR");
        text.setLength(255);
        text.setHidden(true);
        text.setComponentType(componentType + "Text");

        return List.of(main, text);
    }

    /**
     * 生成 data-picker 字段的两列映射：
     * <key> TEXT 存被引用记录 id 数组（JSON，如 ["u1","u2"]；单选为 ["u1"]）
     * <key>_text TEXT 存冗余显示文本数组（JSON，hidden=true）
     *
     * @param key   字段 key
     * @param props form-create rule 的 props（sourceFormKey/displayField/maxCount）
     * @return 两列映射
     */
    public static List<ColumnConfig> mapPickerToColumns(String key, Map<String, Object> props) {
        ColumnConfig idCol = new ColumnConfig();
        idCol.setKey(key);
        idCol.setColumnType("TEXT");
        idCol.setComponentType("dataPicker");

        Map<String, Object> picker = new LinkedHashMap<>();
        picker.put("sourceFormKey", props == null ? null : props.get("sourceFormKey"));
        picker.put("displayField", props == null ? null : props.get("displayField"));
        // maxCount：缺省 null = 不限（单选语义为 1）
        picker.put("maxCount", props == null ? null : props.get("maxCount"));
        try {
            idCol.setPickerConfig(OBJECT_MAPPER.writeValueAsString(picker));
        } catch (JsonProcessingException e) {
            idCol.setPickerConfig("{}");
        }

        ColumnConfig textCol = new ColumnConfig();
        textCol.setKey(key + "_text");
        textCol.setLabel((props != null && props.get("title") != null) ? String.valueOf(props.get("title")) + "（显示）" : null);
        textCol.setColumnType("TEXT");
        textCol.setHidden(true);
        textCol.setComponentType("dataPickerText");

        return List.of(idCol, textCol);
    }

    /**
     * 判断列类型是否在允许的白名单内。
     */
    public static boolean isAllowedColumnType(String columnType) {
        return columnType != null && ALLOWED_TYPES.contains(columnType);
    }

    /**
     * 判断新旧列类型是否为跨大类变更（不允许的 DDL 变更）。
     * 字符串类(VARCHAR/TEXT)、整数类(INT)、小数类(DECIMAL)、日期类(DATE/DATETIME)、其他 之间互相切换视为跨类。
     * 同一大类内的调整（如 VARCHAR 加长、DATE→DATETIME）允许。
     */
    public static boolean isCrossTypeChange(String oldType, String newType) {
        return !categoryOf(oldType).equals(categoryOf(newType));
    }

    private static String categoryOf(String type) {
        if (type == null) return "UNKNOWN";
        return switch (type) {
            case "VARCHAR", "TEXT", "LONGTEXT", "TINYINT", "JSON" -> "STRING";
            case "INT" -> "INT";
            case "DECIMAL" -> "DECIMAL";
            case "DATE", "DATETIME" -> "DATE";
            default -> "UNKNOWN";
        };
    }
}
